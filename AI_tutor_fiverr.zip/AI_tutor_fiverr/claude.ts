require('dotenv').config();
import express, { Request, Response } from 'express';
const cors = require('cors');
const Anthropic = require('@anthropic-ai/sdk');

const app = express();
app.use(express.json());
app.use(cors());

interface ScaffoldConfig {
    grade: string;
    subject: string;
    topic: string;
    lessonType: string;
    rules: string;
}
const total_slides = 6;
const generateArray = (n:number) => {
    let arr = [];
    for (let i = 1; i <= n; i++) {
        arr.push(i);
    }
    return arr;
}

const anthropic = new Anthropic({
    apiKey: process.env["ANTHROPIC_API_KEY"]
});
const generateDescription = async (scaffoldConfig: ScaffoldConfig): Promise<Record<string, string>> => {
    const des_prompt = `
As an AI tutor assistant, generate concise descriptions for scaffolds of ${total_slides} slides. Each description should enable independent scaffold creation. Respond only in the specified JSON format.

Lecture Details:
- Topic: ${scaffoldConfig.topic}
- Grade Level: ${scaffoldConfig.grade}
- Subject: ${scaffoldConfig.subject}
- Lecture Type: ${scaffoldConfig.lessonType}

Rules to Follow:
${scaffoldConfig.rules}

Guidelines for Scaffold Descriptions:
1. Each description should be brief but informative.
2. Include key points or concepts to be covered in each slide.
3. Ensure a logical flow and progression across all slides.
4. Tailor the content to the specified grade level and subject.
5. Incorporate elements relevant to the lecture type.
6. Adhere to the provided rules in your descriptions.
7. Use clear and concise language.
8. Avoid repetitive content across slides unless necessary.
9. Include suggestions for visual elements or examples where appropriate.
10. Ensure each slide description can stand alone for individual scaffold creation.

Generate the scaffold descriptions in the following JSON format:

{
  "slide1": "Description for slide 1",
  "slide2": "Description for slide 2",
  ...
  "slide${total_slides}": "Description for slide ${total_slides}"
}

Your response should contain only this JSON object, without any additional text or explanations.
`
    const des = await anthropic.messages.create({
        model: "claude-3-5-sonnet-20240620",
        max_tokens: 3000,
        messages: [{role: "user", content: des_prompt}],
    });

    //@ts-ignore
    const desOut = des.content[0].text
    const desStartIndex = desOut.indexOf('{');
    const desString =  desOut.slice(desStartIndex);
    const desParsed = JSON.parse(desString);
    // console.log(desParsed);
    return desParsed;
}


// const generatePrompt = (slideNumber:number, scaffoldDesc: string) => `
// Generate a markdown scaffold using the given description for slide ${slideNumber}/${total_slides}
// Description: ${scaffoldDesc}
// Topic: ${scaffold_config.topic}
// Grade: ${scaffold_config.grade}
// Tutor Rules: ${scaffold_config.rules}
//
// Guidelines:
// 1. Use only markdown syntax
// 2. Don't enclose markdown in punctuation
// 3. No starter text or explanations
// 4. Focus on slide content structure
// 5. Ensure grade-appropriate material
// 6. Align with lesson type and subject
// `;
//
//
// const generateSlide = async (slideNumber:number, desc:string) => {
//     try {
//         const msg = await anthropic.messages.create({
//             model: "claude-3-5-sonnet-20240620",
//             max_tokens: 1000,
//             messages: [{ role: "user", content: generatePrompt(slideNumber, desc) }],
//         });
//         //@ts-ignore
//         const rawOutput = msg.content[0].text;
//         console.log(rawOutput)
//         return rawOutput;
//     } catch (error) {
//         console.error(`Error generating slide ${slideNumber}:`, error);
//         return { [`slide${slideNumber}`]: "" };
//     }
// };
const generateSlide = async (
    slideNumber: number,
    scaffoldDesc: string,
    scaffoldConfig: ScaffoldConfig
): Promise<string> => {
`Generate a markdown scaffold using the given description for slide ${slideNumber}/${total_slides}
Description: ${scaffoldDesc}
Topic: ${scaffoldConfig.topic}
Grade: ${scaffoldConfig.grade}
Tutor Rules: ${scaffoldConfig.rules}

Guidelines:
    1. Use only markdown syntax
2. Don't enclose markdown in punctuation
3. No starter text or explanations
4. Focus on slide content structure
5. Ensure grade-appropriate material
6. Align with lesson type and subject
`;

    const msg = await anthropic.messages.create({
        model: 'claude-3-5-sonnet-20240620',
        max_tokens: 1000,
        messages: [{ role: 'user', content: prompt }],
    });

    return msg.content[0].text;
};

// Type for the request body to enforce TypeScript typing
interface GenerateScaffoldRequest extends Request {
    body: ScaffoldConfig;
}

// const main = async () => {
//     try {
//         const description = await generateDescription()
//         console.log(description)
//         const slidePromises = generateArray(total_slides).map(async (num) => {
//             const slideKey = `slide${num}`;
//             const slideContent = await generateSlide(num, description[slideKey]);
//
//             // Create a filename, e.g., "slide1.md"
//             const fileName = `slide${num}.md`;
//
//             // Write the slide content to the file
//             await fs.writeFile(fileName, slideContent, 'utf-8');
//             console.log(`Slide ${num} written to ${fileName}`);
//
//             return slideContent; // Return slide content for logging purposes
//         });
//         const slides = await Promise.all(slidePromises);
//         console.log("ALL scaffolds has been written: ",slides)
//         return slides
//     } catch (error) {
//         console.error("Error generating slides:", error);
//     }
// };
app.post('/generate-scaffold', async (req: GenerateScaffoldRequest, res: Response) => {
    const scaffoldConfig = req.body;

    try {
        // Generate slide descriptions
        const description = await generateDescription(scaffoldConfig);

        // Generate markdown for each slide
        const slides = await Promise.all(
            generateArray(total_slides).map(async (num) => {
                const slideKey = `slide${num}`;
                const slideContent = await generateSlide(num, description[slideKey], scaffoldConfig);
                return slideContent;
            })
        );

        res.json({ slides });
    } catch (error) {
        console.error('Error generating scaffold:', error);
        res.status(500).json({ error: 'Error generating scaffold' });
    }
});

app.post('/generate-scaffold-code', async (req: GenerateScaffoldRequest, res: Response) => {

});
// Start the server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});