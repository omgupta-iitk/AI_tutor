var main = function () {
    console.log("Hello World!");
};
main();
