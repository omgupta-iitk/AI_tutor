# Summary and Exercise

## Key Points

- 
- 
- 

## Problem-Solving Exercise

### Question:

### Given:
- 
- 

### Instructions:
1. 
2. 
3. 

### Hint:

[Space for student work]