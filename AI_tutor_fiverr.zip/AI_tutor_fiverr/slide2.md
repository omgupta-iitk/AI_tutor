## Slide 2: Characteristics of Adiabatic Compression

### Key Points

1. Temperature increase
2. No heat exchange
3. Energy conservation

### Temperature Changes

- Gas gets hotter during compression
- Rapid process prevents heat transfer

### Energy Principles

- Work done on gas
- Internal energy increases
- No heat added or removed

### Real-World Examples

- Diesel engines
- Air pumps
- Weather systems