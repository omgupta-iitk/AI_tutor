`import React from 'react';
import { Typography, Box, List, ListItem, ListItemText, Divider } from '@mui/material';

const CompressionEquationSlide = () => {
  return (
    <Box sx={{ padding: '20px', backgroundColor: '#f0f8ff', borderRadius: '10px' }}>
      <Typography variant="h3" gutterBottom align="center" sx={{ color: '#1a5f7a' }}>
        Adiabatic Compression Equation
      </Typography>

      <Typography variant="h4" align="center" sx={{ marginY: '20px', color: '#2c7da0' }}>
        PV<sup>γ</sup> = constant
      </Typography>

      <List>
        <ListItem>
          <ListItemText primary="P: Pressure" />
        </ListItem>
        <ListItem>
          <ListItemText primary="V: Volume" />
        </ListItem>
        <ListItem>
          <ListItemText primary="γ (gamma): Heat capacity ratio" />
        </ListItem>
      </List>

      <Divider sx={{ marginY: '20px' }} />

      <Typography variant="h5" gutterBottom sx={{ color: '#2c7da0' }}>
        Significance of γ (gamma)
      </Typography>

      <List>
        <ListItem>
          <ListItemText primary="Ratio of specific heats" />
        </ListItem>
        <ListItem>
          <ListItemText primary="Depends on gas type" />
        </ListItem>
        <ListItem>
          <ListItemText primary="Affects compression behavior" />
        </ListItem>
      </List>

      <Divider sx={{ marginY: '20px' }} />

      <Typography variant="h5" gutterBottom sx={{ color: '#2c7da0' }}>
        Key Points
      </Typography>

      <List>
        <ListItem>
          <ListItemText primary="Relationship between pressure and volume" />
        </ListItem>
        <ListItem>
          <ListItemText primary="No heat exchange with surroundings" />
        </ListItem>
        <ListItem>
          <ListItemText primary="Important in thermodynamics and engineering" />
        </ListItem>
      </List>
    </Box>
  );
};

export default CompressionEquationSlide;`