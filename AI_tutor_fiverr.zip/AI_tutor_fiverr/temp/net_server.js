// const net= require('net')
// let server = net.createServer((socket) => {
//     socket.end("good bye\n");
// }).on("error", (err) => {throw err;});
//
// server.listen(() => {
//     address = server.address();
//     console.log("Server listening on port %j",address);
// })
// console.log('Happy developing ✨')
// function welcome () {
//     console.log("Welcome to JavaTpoint!");
//     clearInterval(id2);
// }
// // var id1 = setTimeout(welcome,1000);
// var id2 = setInterval(welcome,3000);
// // var id3 = setTimeout(welcome,1000);
// //clearTimeout(id1);
// const os=require('os');
// console.log("os.freemem(): \n",os.freemem()/(1000*1000));
// console.log("os.homedir(): \n",os.homedir());
// console.log("os.hostname(): \n",os.hostname());
// console.log("os.endianness(): \n",os.endianness());
// console.log("os.loadavg(): \n",os.loadavg());
// console.log("os.platform(): \n",os.platform());
// console.log("os.release(): \n",os.release());
// console.log("os.tmpdir(): \n",os.tmpdir());
// console.log("os.totalmem(): \n",os.totalmem());
// console.log("os.type(): \n",os.type());
// console.log("os.uptime(): \n",os.uptime());
//
// // const os=require('os');
// console.log("os.cpus(): \n",os.cpus());
// console.log("os.arch(): \n",os.arch());
// console.log("os.networkInterfaces(): \n",os.networkInterfaces());
//
// const dns = require('dns');
// dns.resolve4('www.google.com', (err, addresses) => {
//     if (err) throw err;
//     console.log(`addresses: ${JSON.stringify(addresses)}`);
//     addresses.forEach((a) => {
//         dns.reverse(a, (err, hostnames) => {
//             if (err) {
//                 throw err;
//             }
//             console.log(`reverse for ${a}: ${JSON.stringify(hostnames)}`);
//         });
//     });
// });
async function main() {
    const readline = require('node:readline');

    const rl =  readline.createInterface({
        input: process.stdin,
        output: process.stdout,
    });

    const question = (query) => new Promise(resolve => rl.question(query, resolve));

    const name = await question(`What's your name? `);
    console.log(`Hi ${name}!`);
     console.log("Getting started");
}

main();