# Slide 1: What is Adiabatic Compression?

## Definition
- Adiabatic compression: A process where gas is compressed without heat exchange with its surroundings

## Basic Principle
- As gas is compressed, its temperature increases
- No heat enters or leaves the system during compression

## Real-World Example
- Diesel engines use adiabatic compression
  - Air is rapidly compressed in the cylinder
  - Temperature rises high enough to ignite fuel without a spark