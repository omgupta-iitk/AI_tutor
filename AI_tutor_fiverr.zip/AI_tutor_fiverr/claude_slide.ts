require('dotenv').config();
const fs = require('fs').promises;
const Anthropic = require('@anthropic-ai/sdk');


const total_slides = 1;
const generateArray = (n:number) => {
    let arr = [];
    for (let i = 1; i <= n; i++) {
        arr.push(i);
    }
    return arr;
}

const anthropic = new Anthropic({
    apiKey: process.env["ANTHROPIC_API_KEY"]
});

// const generatePrompt = (slideNumber:number) => `
// System: Generate the slide based on the given scaffold following the given slide requirements and respond only in the code.
// Scaffold: ${slideContent},
// Slide Requirements: ${slideRequirement},
// Response: string
// Note: Do not include code inside any punctuation also do not print any starter response.
// `
const generatePrompt= (slideContent:string , slideRequirement: string ) => `
Generate the react code for the slide based on the given scaffold and requirements. Your response should contain only the slide content, without any additional commentary or markup.

Scaffold:
${slideContent}

Slide Requirements:
${slideRequirement}

Important guidelines:
1. Use the scaffold as a structural guide for the slide content.
2. Adhere strictly to the provided slide requirements.
3. Respond with the slide content only, without any surrounding code blocks or quotation marks.
4. Do not include any prefacing statements, explanations, or conclusions.
5. Ensure the content is fully developed and appropriate for the intended audience.
6. Use clear and concise language suitable for presentation slides.
7. Maintain proper formatting and structure for easy readability.
8. Include any necessary bullet points, numbered lists, or headings as appropriate.
9. If the requirements specify any particular style or tone, ensure it is consistently applied.
10. Double-check that all required elements from the scaffold and requirements are included in the final slide.

Response: 
code

`

const generateSlide = async (slideReq: string, scaffold:string) => {
    try {
        const msg = await anthropic.messages.create({
            model: "claude-3-5-sonnet-20240620",
            max_tokens: 1000,
            messages: [{ role: "user", content: generatePrompt( slideReq, scaffold) }],
        });
        //@ts-ignore
        const rawOutput = msg.content[0].text;
        console.log(rawOutput)
        return rawOutput;
    } catch (error) {
        console.error(`Error generating slide:`, error);
        return { [`slide`]: "" };
    }
};

const main = async () => {
    try {
        type SlideRequest = {
            [key: string]: string;
        };

        type Scaffold = {
            [key: string]: string;
        };
        const slide_req: SlideRequest = {
            "slide1" : "the title of the slide should be Compression Equation and follow the scaffold for generating and slide should be visually attractive.",
            "slide2" : "",
            "slide3" : "",
            "slide4" : "",
            "slide5" : "",
            "slide6" : ""
        }
        const scaffolds: Scaffold = {
            "slide1" : `
            
# Adiabatic Compression Equation

## PVγ = constant

- **P**: Pressure
- **V**: Volume
- **γ** (gamma): Heat capacity ratio

---

### Significance of γ (gamma)

- Ratio of specific heats
- Depends on gas type
- Affects compression behavior

---

### Key Points

- Relationship between pressure and volume
- No heat exchange with surroundings
- Important in thermodynamics and engineering
            `,
            "slide2" : "",
            "slide3" : "",
            "slide4" : "",
            "slide5" : "",
            "slide6" : ""
        }


        const slidePromises = generateArray(total_slides).map(async (num) => {
            const slideKey = `slide${num}`;
            const slideContent = await generateSlide( slide_req[slideKey] , scaffolds[slideKey] );
            console.log(slideContent)

            // Create a filename, e.g., "slide1.md"
            const fileName = `code${num}.md`;

            // Write the slide content to the file
            await fs.writeFile(fileName, slideContent, 'utf-8');
            console.log(`Slide ${num} written to ${fileName}`);

            return slideContent; // Return slide content for logging purposes
        });
        const slides = await Promise.all(slidePromises);
        console.log("ALL scaffolds has been written: ",slides)
    } catch (error) {
        console.error("Error generating slides:", error);
    }
};
main()










// require('dotenv').config();
// const fs = require('fs').promises;
// import Anthropic from '@anthropic-ai/sdk';
//
// const slide_req = {
//     slide1 : "",
//     slide2 : "",
//     slide3 : "",
//     slide4 : "",
//     slide5 : "",
//     slide6 : "",
// }
//
// const tutor_conf = {
//     tutor_type: "",
//     tutor_req: "",
// }
//
// const anthropic = new Anthropic({
//     apiKey: process.env["ANTHROPIC_API_KEY"]
// });
//
// const generateSlide = async (slideNumber:number, slideContent:string, slideRequirement:string) => {
//     // Simulating generating slide code from scaffold content
//     const prompt2 = `
//     System: Generate the slide based on the given scaffold following the given slide requirements and respond only in the code.
//     Scaffold: ${slideContent},
//     Slide Requirements: ${slideRequirement},
//     Response: string
//     Note: Do not include code inside any punctuation also do not print any starter response.
//     `
//     const slideCode = await anthropic.messages.create({
//         model: "claude-3-5-sonnet-20240620",
//         max_tokens: 5000,
//         messages: [{ role: "user", content: prompt2 }],
//     });
//     //@ts-ignore
//     const code = slideCode.content[0].text
//     console.log(code)
//     return code;
// };
// const scaffold = {
//     slide1: "# Let's Learn About Sentences!\n\n- What is a sentence?\n- Why are sentences important?\n- Fun fact: Every sentence tells a story!",
// }
// console.log(generateSlide(1, scaffold.slide1, slide_req.slide1))
//
// const main = async () => {
//     try {
//         const msg = await anthropic.messages.create({
//             model: "claude-3-5-sonnet-20240620",
//             max_tokens: 5000,
//             messages: [{ role: "user", content: prompt1 }],
//         });
//         //@ts-ignore
//         const rawOutput = msg.content[0].text
//         const jsonStartIndex = rawOutput.indexOf('{'); // Find the first curly brace
//         const jsonString = rawOutput.slice(jsonStartIndex);
//
//         console.log(jsonString);
//         const scaffold = JSON.parse(jsonString);
//         console.log(scaffold); // Successfully parsed JSON object
//         // Extract individual slides
//         const slides = [
//             { number: 1, content: scaffold.slide1, sld_req: slide_req.slide1 },
//             { number: 2, content: scaffold.slide2, sld_req: slide_req.slide2 },
//             { number: 3, content: scaffold.slide3, sld_req: slide_req.slide3 },
//             { number: 4, content: scaffold.slide4, sld_req: slide_req.slide4 },
//             { number: 5, content: scaffold.slide5, sld_req: slide_req.slide5 },
//             { number: 6, content: scaffold.slide6, sld_req: slide_req.slide6 }
//         ];
//
//         // Generate and write slides concurrently using Promise.all
//         const slidePromises = slides.map(async (slide) => {
//             const slideCode = await generateSlide(slide.number, slide.content, slide.sld_req);
//             await writeSlideToFile(slide.number, slideCode); // Write each slide to file
//         });
//
//         // Wait for all slides to be generated and written to files
//         await Promise.all(slidePromises);
//
//         console.log('All slides have been generated and saved to files.');
//
//     } catch (error) {
//         console.error("Error generating slides:", error);
//     }
// };
